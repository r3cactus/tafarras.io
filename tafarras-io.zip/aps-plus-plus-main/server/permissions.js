module.exports = [
    {
        "key": 10467,
        "discordID": "1399747933926199296",
        "nameColor": "#2d45fc",
        "class": "developer",
        "infiniteLevelUp": true,
        "name": "foxhunterpro",
        "note": "note here"
    },
    {
        "key": process.env.TOKEN_2,
        "discordID": "0",
        "nameColor": "#ffffff",
        "class": "developer",
        "infiniteLevelUp": true,
        "name": "unnamed#0000",
        "note": "note here"
    },
    {
        "key": process.env.TOKEN_3,
        "discordID": "0",
        "nameColor": "#ffffff",
        "class": "developer",
        "infiniteLevelUp": true,
        "name": "unnamed#0000",
        "note": "note here"
    },
    {
        "key": 863911,
        "discordID": "0",
        "nameColor": "#ffffff",
        "class": "developer",
        "infiniteLevelUp": true,
        "name": "unnamed#0000",
        "note": "note here",
        "administrator": true,
    },
]
