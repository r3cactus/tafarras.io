module.exports = {
    DOMINATOR_LOOP: true,
    ROOM_SETUP: ['overlay_domination']
};