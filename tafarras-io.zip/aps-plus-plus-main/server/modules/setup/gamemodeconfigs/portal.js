module.exports = {
    ROOM_SETUP: ['overlay_portal']
};