module.exports = {
	TEAM_WEIGHTS: {
		[TEAM_BLUE]: 1.1
	}
};