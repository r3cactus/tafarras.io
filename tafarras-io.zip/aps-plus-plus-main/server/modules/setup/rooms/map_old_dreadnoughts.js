let { nest } = require('../tiles/misc.js'),
    { doda } = require('../tiles/misc.js'),
    { open: ____, labyrinth, forge, outOfBounds } = require('../tiles/old_dreadnoughts.js'),
    teams = require('../gamemodeconfigs/old_dreadnoughts.js').TEAMS,
    bases = require('../tiles/tdm.js'),

room = [
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____],
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____],
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____],
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____],
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____],
    [____,____,____,____,____,nest,nest,nest,nest,nest,____,____,____,____,____],
    [____,____,____,____,____,nest,nest,nest,nest,nest,____,____,____,____,____],
    [____,____,____,____,____,nest,nest,doda,nest,nest,____,____,____,____,____],
    [____,____,____,____,____,nest,nest,nest,nest,nest,____,____,____,____,____],
    [____,____,____,____,____,nest,nest,nest,nest,nest,____,____,____,____,____],
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____],
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____],
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____],
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____],
    [____,____,____,____,____,____,____,____,____,____,____,____,____,____,____]
];
Config.roomHeight = room.length;
Config.roomWidth = room[0].length;

let locations = [
    [
        [[ 0,  0], [ 1,  0], [ 0,  1]],
        [[ 1,  1]]
    ],[
        [
            [Config.roomHeight - 1, Config.roomWidth - 1], 
            [Config.roomHeight - 2, Config.roomWidth - 1], 
            [Config.roomHeight - 1, Config.roomWidth - 2]
        ],
        [[Config.roomHeight - 2, Config.roomWidth - 2]]
    ],[
        [
            [ 0, Config.roomWidth - 1], 
            [ 1, Config.roomWidth - 1], 
            [ 0, Config.roomWidth - 2]
        ],
        [[ 1, Config.roomWidth - 2]]
    ],[
        [
            [Config.roomHeight - 1,  0], 
            [Config.roomHeight - 1,  1], 
            [Config.roomHeight - 2,  0]
        ],
        [[Config.roomHeight - 2,  1]]
    ]
];

if (teams === 2) {
	let baseprotGap = Math.ceil((Config.roomHeight - 1) / 6);
	for (let y = 0; y < Config.roomHeight; y++) {
		room[y][0] = bases.base1;
		room[y][Config.roomWidth - 1] = bases.base2;
	}
	for (let i = -2; i <= 2; i++) {
		let y = Math.floor(Config.roomHeight / 2 - baseprotGap * i);
		room[y][0] = bases.base1protected;
		room[y][Config.roomWidth - 1] = bases.base2protected;
	}
} else {
	for (let i = 1; i <= teams; i++) {
		let [ spawns, protectors ] = locations[i - 1];
		for (let [y, x] of spawns) room[y][x] = bases[`base${i}`];
		for (let [y, x] of protectors) room[y][x] = bases[`base${i}protected`];
	}
}

for (let row in room) {
    if (row < 11 && row >= 4) {
        room[row].unshift(...Array(4).fill(outOfBounds), ...Array(7).fill(forge), ...Array(4).fill(outOfBounds));
    } else {
        room[row].unshift(...Array(Config.roomWidth).fill(outOfBounds));
    }
}
for (let row of room) {
    row.unshift(...Array(Config.roomWidth).fill(labyrinth));
}

Config.FOOD_TYPES_NEST = [
    [80000, [
        [400, 'pentagon'], [ 1200, 'betaPentagon'], [ 800, 'alphaPentagon'], [ 500, 'hexagonOfficialV1'], [ 400, 'heptagonOfficialV1'], [ 300, 'octagonOfficialV1'], [ 197, 'nonagonOfficialV1'], [3, 'decagonOfficialV1']
    ]],
    [2000, [   
            [1024, 'egg'], [256, 'square'], [64, 'triangle'], [21, 'decagonOfficialV1'], 
        ]],
        [1, [
            [3125, 'gem'], [625, 'shinySquare'], [125, 'shinyTriangle'], [25, 'shinyPentagon'], [5, 'shinyBetaPentagon'], [1, 'shinyAlphaPentagon']
        ]],
        [0.1, [
            [6836, 'jewel'], [1296, 'legendarySquare'], [216, 'legendaryTriangle'], [36, 'legendaryPentagon'], [6, 'legendaryBetaPentagon'], [1, 'legendaryAlphaPentagon']
        ]],
        [0.005, [
            /*[16807, 'egg'], */[2401, 'shadowSquare'], [343, 'shadowTriangle'], [49, 'shadowPentagon'], [7, 'shadowBetaPentagon'], [1, 'shadowAlphaPentagon']
        ]],
        [0.001, [
            /*[65536, 'egg'], */[8192, 'rainbowSquare'], [1024, 'rainbowTriangle'], [64, 'rainbowPentagon'], [8, 'rainbowBetaPentagon'], [1, 'rainbowAlphaPentagon']
        ]],
        [0.0005, [
            [59549, 'egg'], [6561, 'transSquare'], [729, 'transTriangle'], [81, 'transPentagon'], [9, 'transBetaPentagon'], [1, 'transAlphaPentagon']
        ]],
        [0.0001, [
            [100000, 'sphere'], [10000, 'cube'], [1000, 'tetrahedron'], [100, 'octahedron'], [10, 'dodecahedron'], [1, 'icosahedron']
        ]],

    
];

Config.FOOD_TYPES_DODA = [
    [499332, [
        [7776, 'hexagon'], [1296, 'shinyHexagon'], [216, 'legendaryHexagon'], [36, 'shadowHexagon'], [6, 'rainbowHexagon'], [1, 'transHexagon']
    ]],
    [667, [
        [50, 'heptagonOfficialV1'], [50, 'octagonOfficialV1'], [150, 'nonagonOfficialV1'], [750, 'decagonOfficialV1']
    ]],
    [1, [
         [100, 'sphere'], [100, 'cube'], [100, 'tetrahedron'], [100, 'octahedron'], [100, 'dodecahedron'], [75, 'icosahedron'], [25, 'tesseract']
    ]],
];

require('../../gamemodes/oldDreadnoughts.js');

module.exports = room;