#!/usr/bin/sh
while true
do
	node --trace-warnings server/index
	sleep 5
done